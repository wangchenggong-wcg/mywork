$(document).ready(function(){
    $("#b1").click(function(){
        var timestamp = Date.parse(new Date());
        var a = $("#t1").val();
        var b = $("#t2").val();
        var c = $("#t3").val();
        var d = $("#t4").val();
        var e = $("#t5").val();
        var f = $("#t6").val();
        var g = $("#t7").val();
        var h = $("#t8").val();
        var i = $("#t9").val();
        var j = $("#t10").val();
        var k = $("#t11").val();
        var r = $("#t12").val();
        var m = $("#t13").val();
        var n = $("#t14").val();
        var o = $("#t15").val();
        var p = $("#t16").val();
        var q = $("#t17").val();
        var l = $("#t18").val();
        var s = $("#t19").val();
        $.ajax({
            url:"test",
            type:"post",
            data:{
                "aa":a,
                "bb":b,
                "cc":c,
                "dd":d,
                "ee":e,
                "ff":f,
                "gg":g,
                "hh":h,
                "ii":i,
                "jj":j,
                "kk":k,
                "rr":r,
                "mm":m,
                "nn":n,
                "oo":o,
                "pp":p,
                "qq":q,
                "ll":l,
                "ss":s
            },
            success:function(msg){ //服务器返回数据
                $("#img").attr("src",msg);
            }
            
        });

    });
});