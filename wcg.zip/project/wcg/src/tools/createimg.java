package tools;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.text.SimpleDateFormat;
import java.util.Date;


public class createimg {

	public BufferedImage getimg(String aa,String bb,String cc,String dd,String ee,String ff) {
		int h=649;
		int w=433;
		BufferedImage image = new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);
		Graphics gr=image.getGraphics();
		//使用画笔工具
		gr.setColor(Color.white);
		gr.fillRect(0, 0, w, h);
		//将图片背景设置为白色
		gr.setColor(Color.black);
		
		gr.drawString("始发网点："+"武汉市江夏区流放YD", 10, 20);
		gr.drawString("寄件人："+"WM", 10, 40);
		gr.drawString("寄件人电话："+"74286000000", 100, 40);
		gr.drawString("寄件人地址："+"Birmingham", 10, 60);
		
		gr.drawString("收件人："+"刘丹", 30, 100);
		gr.drawString("收件人电话："+"1347896243", 30, 120);
		gr.drawString("收件公司："+"", 30, 140);
		gr.drawString("收件地址："+"山西省太原市小店区南中环体育路口", 30, 160);
		
		gr.drawString("集包地："+"太原市内包", 20, 200);
		gr.drawString("180-E069-00", 30, 240);
		
		gr.drawString("收件人/签收人："+"", 20, 300);
		gr.drawString("签收日期："+"", 150, 300);
		gr.drawString("Name of Sign-off："+"", 20, 320);
		
		gr.drawString("数量："+"3.6", 20, 340);
		gr.drawString("11", 20, 380);
		
		gr.drawString("韵达"+"", 300, 400);
		
		gr.drawString("寄件人："+"WM", 10, 420);
		gr.drawString("寄件人电话："+"74286000000", 100, 420);
		gr.drawString("寄件人地址："+"Birmingham", 10, 440);
		
		gr.drawString("收件人："+"刘丹", 10, 460);
		gr.drawString("收件人电话："+"1347896243", 10, 480);
		gr.drawString("收件公司："+"", 10, 500);
		gr.drawString("收件地址："+"山西省太原市小店区南中环体育路口", 10, 520);
		
		gr.drawString("官方地址"+"http://www.baidu.com"+"客服热线"+"95536", 10, 550);
		
		gr.setColor(new Color(255,0, 0));
		gr.drawString(cc, 10, 100);
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");//设置日期格式
        String date = df.format(new Date());// new Date()为获取当前系统时间
        gr.drawString(date, 90, 340);
		
        
		
		return image;
	}
}
